var namespaces_dup =
[
    [ "tests", "namespacetests.html", "namespacetests" ]
];