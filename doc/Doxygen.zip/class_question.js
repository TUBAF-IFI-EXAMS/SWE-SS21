var class_question =
[
    [ "Question", "class_question.html#abc0fd62f90e85d681d5cf75a2bfaf57d", null ],
    [ "GetResponseDeclaration", "class_question.html#a41188a6150e59d632f0c35fb237b708e", null ],
    [ "Points", "class_question.html#afd54dc6497a1d7a1f8df760d481beec2", null ],
    [ "TestNumber", "class_question.html#ab6f3a35b1a8ea872956812ba654ffb09", null ],
    [ "Text", "class_question.html#acf03a4229fba37a8e25cc1d58ec882cb", null ]
];