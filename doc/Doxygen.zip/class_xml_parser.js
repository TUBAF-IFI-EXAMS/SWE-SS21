var class_xml_parser =
[
    [ "XmlParser", "class_xml_parser.html#aa6113a0e2f0951f44a8a0ed43f2ac6ea", null ],
    [ "ReadSection", "class_xml_parser.html#a9c71279d5230982b24b491c5cd924aeb", null ],
    [ "SetSource", "class_xml_parser.html#a542159bbf7a1160753e78271ac05c504", null ]
];