var hierarchy =
[
    [ "fString", "classf_string.html", null ],
    [ "IEnumerable", null, [
      [ "Ixml", "interface_ixml.html", [
        [ "Paragraph", "class_paragraph.html", null ]
      ] ]
    ] ],
    [ "IScoring", "interface_i_scoring.html", [
      [ "ChoiceQuestion", "class_choice_question.html", [
        [ "MultipleChoice", "class_multiple_choice.html", null ],
        [ "SingleChoice", "class_single_choice.html", null ]
      ] ]
    ] ],
    [ "tests.ParserTest", "classtests_1_1_parser_test.html", null ],
    [ "Question", "class_question.html", [
      [ "ChoiceQuestion", "class_choice_question.html", null ]
    ] ],
    [ "XmlParser", "class_xml_parser.html", null ]
];