var interface_i_scoring =
[
    [ "GetOutcome", "interface_i_scoring.html#a52cd572587c169e5f1eb695011f2c6d4", null ]
];