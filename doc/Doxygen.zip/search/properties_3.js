var searchData=
[
  ['points_63',['Points',['../class_question.html#afd54dc6497a1d7a1f8df760d481beec2',1,'Question']]]
];
