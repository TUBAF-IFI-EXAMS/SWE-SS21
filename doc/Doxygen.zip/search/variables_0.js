var searchData=
[
  ['correctanswer_61',['correctAnswer',['../class_single_choice.html#ac6c6806590ac24c352f85b2331489585',1,'SingleChoice']]]
];
