var searchData=
[
  ['iscoring_13',['IScoring',['../interface_i_scoring.html',1,'']]],
  ['ixml_14',['Ixml',['../interface_ixml.html',1,'']]]
];
