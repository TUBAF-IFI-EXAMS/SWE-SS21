var searchData=
[
  ['choicequestion_1',['ChoiceQuestion',['../class_choice_question.html',1,'']]],
  ['correctanswers_2',['correctAnswers',['../class_multiple_choice.html#aef45ca8fb4d053d671165e9c82198a70',1,'MultipleChoice']]]
];
