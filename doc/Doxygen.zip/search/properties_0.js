var searchData=
[
  ['correctanswers_60',['correctAnswers',['../class_multiple_choice.html#aef45ca8fb4d053d671165e9c82198a70',1,'MultipleChoice']]]
];
