var searchData=
[
  ['format_3',['Format',['../classf_string.html#aba52a86c5e65f17abc4bdae25bf01810',1,'fString']]],
  ['fstring_4',['fString',['../classf_string.html',1,'fString'],['../classf_string.html#abda519d4387dc2a0cc28fed644e55af1',1,'fString.fString(string Text)'],['../classf_string.html#affcbc431fd7bb5bb1e934d3d15b328f7',1,'fString.fString()']]]
];
