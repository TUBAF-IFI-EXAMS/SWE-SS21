var searchData=
[
  ['testnumber_25',['TestNumber',['../class_question.html#ab6f3a35b1a8ea872956812ba654ffb09',1,'Question']]],
  ['tests_26',['tests',['../namespacetests.html',1,'']]],
  ['text_27',['Text',['../classf_string.html#a0f038379cd57bec1d96343d1c9ad4642',1,'fString.Text()'],['../class_question.html#acf03a4229fba37a8e25cc1d58ec882cb',1,'Question.Text()']]],
  ['textcolor_28',['TextColor',['../classf_string.html#a9bf6c539b1ff9eb3e96dacbe4d228d26',1,'fString']]],
  ['toqti_29',['ToQti',['../classf_string.html#a7003362dafe037c16bc6919cce27c2e3',1,'fString']]]
];
