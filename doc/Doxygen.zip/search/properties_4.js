var searchData=
[
  ['testnumber_64',['TestNumber',['../class_question.html#ab6f3a35b1a8ea872956812ba654ffb09',1,'Question']]],
  ['text_65',['Text',['../classf_string.html#a0f038379cd57bec1d96343d1c9ad4642',1,'fString.Text()'],['../class_question.html#acf03a4229fba37a8e25cc1d58ec882cb',1,'Question.Text()']]],
  ['textcolor_66',['TextColor',['../classf_string.html#a9bf6c539b1ff9eb3e96dacbe4d228d26',1,'fString']]]
];
