var searchData=
[
  ['iscoring_33',['IScoring',['../interface_i_scoring.html',1,'']]],
  ['ixml_34',['Ixml',['../interface_ixml.html',1,'']]]
];
