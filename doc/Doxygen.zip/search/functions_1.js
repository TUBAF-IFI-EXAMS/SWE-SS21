var searchData=
[
  ['fstring_43',['fString',['../classf_string.html#abda519d4387dc2a0cc28fed644e55af1',1,'fString.fString(string Text)'],['../classf_string.html#affcbc431fd7bb5bb1e934d3d15b328f7',1,'fString.fString()']]]
];
