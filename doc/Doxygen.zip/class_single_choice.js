var class_single_choice =
[
    [ "SingleChoice", "class_single_choice.html#ac17562b85ec7a08db39990389665af70", null ],
    [ "GetResponse", "class_single_choice.html#a3d4d6320363402d58b510740f896bdf9", null ],
    [ "GetResponseDeclaration", "class_single_choice.html#ac96a5138e426207cd620aad3495414d4", null ],
    [ "correctAnswer", "class_single_choice.html#ac6c6806590ac24c352f85b2331489585", null ]
];