var class_multiple_choice =
[
    [ "MultipleChoice", "class_multiple_choice.html#a082b0a4630915680936ba0bf6de8b392", null ],
    [ "GetResponse", "class_multiple_choice.html#a9381d239af7ccb46549e3f339e6503b0", null ],
    [ "GetResponseDeclaration", "class_multiple_choice.html#a1df6d5d275d7146ce6e62c0524871c1a", null ],
    [ "correctAnswers", "class_multiple_choice.html#aef45ca8fb4d053d671165e9c82198a70", null ]
];