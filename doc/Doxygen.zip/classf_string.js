var classf_string =
[
    [ "fString", "classf_string.html#abda519d4387dc2a0cc28fed644e55af1", null ],
    [ "fString", "classf_string.html#affcbc431fd7bb5bb1e934d3d15b328f7", null ],
    [ "AddFormat", "classf_string.html#a1f5855289b005a7c7757a7576e251db1", null ],
    [ "GetFormat", "classf_string.html#a8b0d8623c0f0a55926f59f99cdfb9463", null ],
    [ "GetSize", "classf_string.html#a8a947e5ad536e2250fdd2dcb8d096c0b", null ],
    [ "RemoveFormat", "classf_string.html#ad9fd9cf6e4fe77bda01382ca55a77f95", null ],
    [ "RemoveFormat", "classf_string.html#a2a06387a18d1c772230a2d0c7986fd71", null ],
    [ "SetSize", "classf_string.html#a18e2a56ac9bf23e1fe78f7b00041242f", null ],
    [ "SetSize", "classf_string.html#aa86579ae0e5a596c56f33f07578eb7f6", null ],
    [ "ToQti", "classf_string.html#a7003362dafe037c16bc6919cce27c2e3", null ],
    [ "Format", "classf_string.html#aba52a86c5e65f17abc4bdae25bf01810", null ],
    [ "Highlight", "classf_string.html#a4e9c642d1ec47422d7685957412de95f", null ],
    [ "Text", "classf_string.html#a0f038379cd57bec1d96343d1c9ad4642", null ],
    [ "TextColor", "classf_string.html#a9bf6c539b1ff9eb3e96dacbe4d228d26", null ]
];