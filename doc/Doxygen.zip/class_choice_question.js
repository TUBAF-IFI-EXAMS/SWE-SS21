var class_choice_question =
[
    [ "ChoiceQuestion", "class_choice_question.html#ae70b0014966b75ea72646dc25a4afd5f", null ],
    [ "GetChoices", "class_choice_question.html#aeabdf976b49a80b95f6f0ae3fe9e2a5b", null ],
    [ "GetOutcome", "class_choice_question.html#abd13496815dc903b447cc09f5fc679e4", null ],
    [ "GetResponse", "class_choice_question.html#ae51227ec3450a797a20686573a5fe57d", null ],
    [ "GetResponseDeclaration", "class_choice_question.html#a5cbd348a81bfc869d2ab015de0348e38", null ],
    [ "Options", "class_choice_question.html#a835d20b7867ecb299c21c79393737aeb", null ]
];