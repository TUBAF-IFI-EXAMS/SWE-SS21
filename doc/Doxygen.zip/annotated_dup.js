var annotated_dup =
[
    [ "tests", "namespacetests.html", [
      [ "ParserTest", "classtests_1_1_parser_test.html", "classtests_1_1_parser_test" ]
    ] ],
    [ "ChoiceQuestion", "class_choice_question.html", "class_choice_question" ],
    [ "fString", "classf_string.html", "classf_string" ],
    [ "IScoring", "interface_i_scoring.html", "interface_i_scoring" ],
    [ "Ixml", "interface_ixml.html", null ],
    [ "MultipleChoice", "class_multiple_choice.html", "class_multiple_choice" ],
    [ "Paragraph", "class_paragraph.html", "class_paragraph" ],
    [ "Question", "class_question.html", "class_question" ],
    [ "SingleChoice", "class_single_choice.html", "class_single_choice" ],
    [ "XmlParser", "class_xml_parser.html", "class_xml_parser" ]
];